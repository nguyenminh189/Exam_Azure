﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Exam1.Entities;
using Exam1.Models;


namespace Exam1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
public class ProjectEmployeeController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ProjectEmployeeController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ProjectEmployee>>> GetProjectEmployees()
    {
        return await _context.ProjectEmployees
            .Include(pe => pe.Employees)
            .Include(pe => pe.Projects)
            .ToListAsync();
    }

    [HttpPost]
    public async Task<ActionResult<ProjectEmployee>> PostProjectEmployee(ProjectEmployee projectEmployee)
    {
        _context.ProjectEmployees.Add(projectEmployee);
        await _context.SaveChangesAsync();
        return CreatedAtAction("GetProjectEmployees", new { id = projectEmployee.EmployeeId }, projectEmployee);
    }
}
}

